﻿Public Class frm_mainPage

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_logout.Click
        Me.Close()
        frm_login.Show()
    End Sub

    Private Sub btn_docs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_docs.Click

    End Sub

    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click

    End Sub

    Private Sub frm_mainPage_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btn_logs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_logs.Click

    End Sub

    Private Sub btn_backUp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_backUp.Click

    End Sub

    Private Sub btn_retrive_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_retrive.Click

    End Sub
End Class
