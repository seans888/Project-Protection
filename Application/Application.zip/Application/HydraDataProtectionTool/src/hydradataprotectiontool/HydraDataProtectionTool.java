/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hydradataprotectiontool;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
 *
 * @author Letty
 */
public class HydraDataProtectionTool extends Application {
    public static Stage stage,stage1;
    public static Connection con = null;
    public static Statement stmt = null;
    @Override
    public void start(Stage stage) throws Exception {
        this.stage1 = stage;
        Parent root = FXMLLoader.load(getClass().getResource("/views/Login.fxml"));
        stage.getIcons().add(new Image("/resources/logokent.png"));
        Scene scene = new Scene(root);
        stage.setTitle("Hydra Data Protection Tool");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        createDB();
        createTable();
        launch(args);
    }
    
    private static void createDB(){
        String createDb = "CREATE DATABASE IF NOT EXISTS DATAPROTECTION";
        
        con = DBConnection.conDB();
        try {
            stmt = con.createStatement();
            stmt.executeUpdate(createDb);
        } catch (SQLException ex) {
            Logger.getLogger(HydraDataProtectionTool.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private static void createTable(){
        String login = "CREATE TABLE IF NOT EXISTS `login_form` (" + " `lf_username` varchar(10) NOT NULL," +
        "`lf_passwd` varchar(8) NOT NULL" + "PRIMARY KEY (lf_username) " +  ")";
        String register = "CREATE TABLE IF NOT EXISTS `register_form` (" + "  `rf_firstname` varchar(10) NOT NULL," +
        "`rf_lastname` varchar(10) NOT NULL," +
        "`rf_username` varchar(10) NOT NULL," +
        "`rf_passwd` varchar(8) NOT NULL," +
        "`rf_retypepasswd` varchar(8) NOT NULL," + "PRIMARY KEY (rf_username), " + "UNIQUE KEY (rf_username)"+ ")";
        
        con = DBConnection.conDB();
        try {
            stmt = con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(HydraDataProtectionTool.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            stmt.execute(login);
        } catch (SQLException ex) {
            Logger.getLogger(HydraDataProtectionTool.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            stmt.execute(register);
        } catch (SQLException ex) {
            Logger.getLogger(HydraDataProtectionTool.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
