/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;


import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Letty
 */
public class LoginController implements Initializable {

    @FXML
    public static Stage registerStage = new Stage();
    Parent registerRoot;
    FXMLLoader register = new FXMLLoader(getClass().getResource("/views/Register.fxml"));
    
    //Main
    @FXML
    public static Stage mainStage = new Stage();
    Parent mainRoot;
    FXMLLoader main = new FXMLLoader(getClass().getResource("/hydradataprotectiontool/Main.fxml"));
    
    @FXML
    private Label lblLoginConfirmation;

    @FXML
    private Hyperlink hyperRegister;

    @FXML
    private JFXTextField txtUsename;

    @FXML
    private JFXPasswordField passwdLPassword;
    
    @FXML
    public void toRegister(ActionEvent event) {
       
        
        try {
            registerRoot = (Parent) register.load();
            registerStage.setScene(new Scene(registerRoot));
            registerStage.getIcons().add(new Image("/resources/logokent.png"));
            registerStage.setTitle("Hydra Data Protection Tool");
            registerStage.show();
            RegisterController.loginStage.close();
        } catch (IOException ex) {
            Logger.getLogger(RegisterController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    @FXML
    public void btnLogin(ActionEvent event) {
        String username = txtUsename.getText();
       String password = passwdLPassword.getText();
       Connection con;
       ResultSet rs;
       String select = "Select 'rf_username', 'rf_passwd' from register_form where 'rf_username'=? AND 'rf_passwd'=?";
       String insert = "Insert into login_form (lf_username, lf_passwd) values(?,?)";
       con = hydradataprotectiontool.DBConnection.conDB();
        try {
            PreparedStatement ps = con.prepareStatement(select);
            ps.setString(1, username);
            ps.setString(2, password);
            ps.execute();
           
                try {
                    mainRoot = (Parent) main.load();
                    mainStage.setScene(new Scene(mainRoot));
                    mainStage.getIcons().add(new Image("/resources/logokent.png"));
                    mainStage.setTitle("Hydra Data Protection Tool");
                    mainStage.show();
                     RegisterController.loginStage.close();
                } catch (IOException ex) {
                    Logger.getLogger(RegisterController.class.getName()).log(Level.SEVERE, null, ex);
                }
           
        } catch (SQLException ex) {
            lblLoginConfirmation.setText("Invalid Username/Password");
            txtUsename.setText("");
            passwdLPassword.setText("");
            System.err.print(ex);
        }
   
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
