/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import com.jfoenix.controls.JFXButton;
import static controllers.MainController.rootPane;
import java.io.FileWriter;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;

import javafx.scene.layout.Pane;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author Letty
 */
public class SideNavController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private JFXButton fileScan;

    @FXML
    private JFXButton backUp;

    @FXML
    private JFXButton memStat;

    @FXML
    private JFXButton retrieve;

    @FXML
    private JFXButton home;
    public static Pane MemCheckPane;
    public static Pane RetrievePane;
    public static Pane BackUpPane;
    public static Pane HomePane;
    public static Pane FileScanPane;
    DateFormat dateFormatSave = new SimpleDateFormat("EEE_d_MMM_yyyy");
    DateFormat timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    Date date = new Date();

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    @FXML
    public void memStatBtn(ActionEvent event) throws IOException {
               SideNavController.MemCheckPane = new Pane();
               MemCheckPane = FXMLLoader.load(getClass().getResource("/views/MemCheck.fxml"));
               controllers.MainController.rootPane.getChildren().add(MemCheckPane);
               controllers.MainController.rootPane.getChildren().remove(HomePane);
               controllers.MainController.rootPane.getChildren().remove(RetrievePane);
               controllers.MainController.rootPane.getChildren().remove(BackUpPane);
               controllers.MainController.rootPane.getChildren().remove(FileScanPane);
               controllers.MainController.rootPane.getChildren().remove(controllers.MainController.LogsViewPane);
               controllers.MainController.navDrawerPane.toFront();
               controllers.MainController.navHamburgerOption.toFront();
               controllers.MainController.mainMenuBarOption.toFront();
              
               
                String ScannedLogs = "Memory Check Clicked";
            try {
                 PrintWriter Logs = new PrintWriter (new FileWriter ("F:\\SampleLogs\\Logs " + dateFormatSave.format(date) + ".txt" , true));
                 Logs.println(ScannedLogs + " " + timeStamp.format(date));
                 Logs.close();
                  System.out.println("File Saved");
            } catch (IOException ex) {
                Logger.getLogger(MemCheckController.class.getName()).log(Level.SEVERE, null, ex);
            }


    }

      @FXML
    public void retrieveBtn(ActionEvent event) throws IOException {
            SideNavController.RetrievePane = new Pane();
               RetrievePane = FXMLLoader.load(getClass().getResource("/views/RetrieveFile.fxml"));
               controllers.MainController.rootPane.getChildren().add(RetrievePane);
               controllers.MainController.rootPane.getChildren().remove(MemCheckPane);
               controllers.MainController.rootPane.getChildren().remove(BackUpPane);
               controllers.MainController.rootPane.getChildren().remove(HomePane);
                controllers.MainController.rootPane.getChildren().remove(FileScanPane);
               controllers.MainController.rootPane.getChildren().remove(controllers.MainController.LogsViewPane);
               controllers.MainController.navDrawerPane.toFront();
               controllers.MainController.navHamburgerOption.toFront();
                controllers.MainController.mainMenuBarOption.toFront();
                
                 String ScannedLogs = "Retrieve Clicked";
            try {
                 PrintWriter Logs = new PrintWriter (new FileWriter ("F:\\SampleLogs\\Logs " + dateFormatSave.format(date) + ".txt" , true));
                 Logs.println(ScannedLogs + " " + timeStamp.format(date))  ;
                 Logs.close();
                  System.out.println("File Saved");
            } catch (IOException ex) {
                Logger.getLogger(MemCheckController.class.getName()).log(Level.SEVERE, null, ex);
            }

    }
    
    @FXML
    public void backUpBtn (ActionEvent event) throws IOException {
            SideNavController.BackUpPane = new Pane();
               BackUpPane = FXMLLoader.load(getClass().getResource("/views/BackUpFile.fxml"));
               controllers.MainController.rootPane.getChildren().add(BackUpPane);
               controllers.MainController.rootPane.getChildren().remove(RetrievePane);
               controllers.MainController.rootPane.getChildren().remove(MemCheckPane);
                controllers.MainController.rootPane.getChildren().remove(HomePane);
                 controllers.MainController.rootPane.getChildren().remove(FileScanPane);
                controllers.MainController.rootPane.getChildren().remove(controllers.MainController.LogsViewPane);
               controllers.MainController.navDrawerPane.toFront();
               controllers.MainController.navHamburgerOption.toFront();
                controllers.MainController.mainMenuBarOption.toFront();
                
                 String ScannedLogs = "Back-up Clicked";
            try {
                 PrintWriter Logs = new PrintWriter (new FileWriter ("F:\\SampleLogs\\Logs " + dateFormatSave.format(date) + ".txt" , true));
                 Logs.println(ScannedLogs + " " + timeStamp.format(date))  ;
                 Logs.close();
                  System.out.println("File Saved");
            } catch (IOException ex) {
                Logger.getLogger(MemCheckController.class.getName()).log(Level.SEVERE, null, ex);
            }

    }
    
    @FXML
    public void homeBtn(ActionEvent event) throws IOException {
               SideNavController.HomePane = new Pane();
               HomePane = FXMLLoader.load(getClass().getResource("/views/Home.fxml"));
               controllers.MainController.rootPane.getChildren().add(HomePane);
               controllers.MainController.rootPane.getChildren().remove(BackUpPane);
               controllers.MainController.rootPane.getChildren().remove(RetrievePane);
               controllers.MainController.rootPane.getChildren().remove(MemCheckPane);
                controllers.MainController.rootPane.getChildren().remove(FileScanPane);
               controllers.MainController.rootPane.getChildren().remove(controllers.MainController.LogsViewPane);
               controllers.MainController.navDrawerPane.toFront();
               controllers.MainController.navHamburgerOption.toFront();
                controllers.MainController.mainMenuBarOption.toFront();
                
                 String ScannedLogs = "Home Clicked";
            try {
                 PrintWriter Logs = new PrintWriter (new FileWriter ("F:\\SampleLogs\\Logs " + dateFormatSave.format(date) + ".txt" , true));
                 Logs.println(ScannedLogs + " " + timeStamp.format(date));
                 Logs.close();
                  System.out.println("File Saved");
            } catch (IOException ex) {
                Logger.getLogger(MemCheckController.class.getName()).log(Level.SEVERE, null, ex);
            }

    }
    
     @FXML
    public void fileScanBtn(ActionEvent event) throws IOException {
        
        SideNavController.FileScanPane = new Pane();
               FileScanPane = FXMLLoader.load(getClass().getResource("/views/FileScan.fxml"));
               controllers.MainController.rootPane.getChildren().add(FileScanPane);
               controllers.MainController.rootPane.getChildren().remove(BackUpPane);
               controllers.MainController.rootPane.getChildren().remove(RetrievePane);
               controllers.MainController.rootPane.getChildren().remove(MemCheckPane);
               controllers.MainController.rootPane.getChildren().remove(controllers.MainController.LogsViewPane);
               controllers.MainController.navDrawerPane.toFront();
               controllers.MainController.navHamburgerOption.toFront();
                controllers.MainController.mainMenuBarOption.toFront();
                
                 String ScannedLogs = "File Scan Clicked";
            try {
                 PrintWriter Logs = new PrintWriter (new FileWriter ("F:\\SampleLogs\\Logs " + dateFormatSave.format(date) + ".txt" , true));
                 Logs.println(ScannedLogs + " " + timeStamp.format(date));
                 Logs.close();
                  System.out.println("File Saved");
            } catch (IOException ex) {
                Logger.getLogger(MemCheckController.class.getName()).log(Level.SEVERE, null, ex);
            }

    }
    
}
