/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import com.jfoenix.controls.JFXDrawer;
import com.jfoenix.controls.JFXHamburger;
import com.jfoenix.transitions.hamburger.HamburgerBackArrowBasicTransition;
import static controllers.SideNavController.FileScanPane;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.ZipOutputStream;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;


/**
 *
 * @author Letty
 */
public class MainController implements Initializable {
    
    @FXML private JFXDrawer navDrawer;
    @FXML private AnchorPane root;
    @FXML private JFXHamburger navHamburger;
    @FXML private MenuBar MainMenuBar;
    public static AnchorPane rootPane;
    public static JFXDrawer navDrawerPane;
    public static JFXHamburger navHamburgerOption;
    public static MenuBar mainMenuBarOption;
    public static Pane LogsViewPane;
    DateFormat dateFormatSave = new SimpleDateFormat("EEE_d_MMM_yyyy");
    DateFormat timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    Date date = new Date();
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       rootPane = root;
       navDrawerPane = navDrawer;
       navHamburgerOption = navHamburger;
       mainMenuBarOption = MainMenuBar;
       
        try {
             // TODO
             HBox navBox = FXMLLoader.load(getClass().getResource("/views/SideNav.fxml"));
             navDrawer.setSidePane(navBox);
             } catch (IOException ex) {
             Logger.getLogger(MainController.class.getName()).log(Level.SEVERE, null, ex);
         }
      
           HamburgerBackArrowBasicTransition transition = new HamburgerBackArrowBasicTransition(navHamburger);
             transition.setRate(-1);
             navHamburger.addEventHandler(MouseEvent.MOUSE_PRESSED,(e)->{
                 transition.setRate(transition.getRate()*-1);
                 transition.play();
             
                 if(navDrawer.isShown())
                 {
                     navDrawer.close();
                 }else
                     navDrawer.open();
             });
               
    }  
    
     
    @FXML
    public void logsDownload(ActionEvent event) {
           
         File f = new File("F:\\SampleLogs\\Logs " + dateFormatSave.format(date) +".zip");
             try (ZipOutputStream out = new ZipOutputStream(new FileOutputStream(f))) {
                 System.out.println("File Saved");
            } catch (IOException ex) {
                Logger.getLogger(MainController.class.getName()).log(Level.SEVERE, null, ex);
            }
             
        String ScannedLogs = "Logs Download Clicked";
            try {
                 PrintWriter Logs = new PrintWriter (new FileWriter ("F:\\SampleLogs\\Logs " + dateFormatSave.format(date) + ".txt" , true));
                 Logs.println(ScannedLogs + " " + timeStamp.format(date));
                 Logs.close();
                  System.out.println("File Saved");
            } catch (IOException ex) {
                Logger.getLogger(MemCheckController.class.getName()).log(Level.SEVERE, null, ex);
            }

    }
    
    @FXML  
    public void logsViews(ActionEvent event) throws IOException {
            MainController.LogsViewPane = new Pane();
            LogsViewPane = FXMLLoader.load(getClass().getResource("/views/LogsView.fxml"));
            rootPane.getChildren().add(LogsViewPane);
            rootPane.getChildren().remove(controllers.SideNavController.BackUpPane);
            rootPane.getChildren().remove(controllers.SideNavController.HomePane);
            rootPane.getChildren().remove(controllers.SideNavController.MemCheckPane);
            rootPane.getChildren().remove(controllers.SideNavController.RetrievePane);
            rootPane.getChildren().remove(controllers.SideNavController.FileScanPane);
            rootPane.getChildren().remove(root);
            navDrawerPane.toFront();
            navHamburgerOption.toFront();
            mainMenuBarOption.toFront();
            
            String ScannedLogs = "Logs Views Clicked";
            try {
                 PrintWriter Logs = new PrintWriter (new FileWriter ("F:\\SampleLogs\\Logs " + dateFormatSave.format(date) + ".txt" , true));
                 Logs.println(ScannedLogs + " " + timeStamp.format(date));
                 Logs.close();
                  System.out.println("File Saved");
            } catch (IOException ex) {
                Logger.getLogger(MemCheckController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    
}
