/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import hydradataprotectiontool.HydraDataProtectionTool;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.stage.Stage;


/**
 * FXML Controller class
 *
 * @author Letty
 */
public class RegisterController implements Initializable {

    /**
     * Initializes the controller class.
     * @param register
     * @return 
     * @throws java.lang.ClassNotFoundException 
     * @throws java.sql.SQLException 
     */
    
    
    @FXML
    private JFXTextField txtUserName;
    @FXML
    private JFXPasswordField passwdPassword;
    @FXML
    private Label lblPasswordConfirmation;
    @FXML
    private JFXTextField txtLastName;
    @FXML
    private JFXTextField txtFirstName;
    @FXML
    private JFXPasswordField passwdRPassword;
    public static Stage loginStage = new Stage();
    public static Parent loginRoot;
    public FXMLLoader login = new FXMLLoader(getClass().getResource("/views/Login.fxml"));
    
    
    @FXML
    public void btnRegSubmit(ActionEvent event){
        String fName = txtFirstName.getText();
        String lName = txtLastName.getText();
        String uName = txtUserName.getText();
        String pWord = passwdPassword.getText();
        String rPasswd = passwdRPassword.getText();
        Connection con = null;  

        if (pWord.equals(rPasswd)){
           
            try {
                String sql = "insert into register_form (rf_firstname,rf_lastname,rf_username,rf_passwd,rf_retypepasswd) values(?,?,?,?,?)";
                con = hydradataprotectiontool.DBConnection.conDB();
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, fName);
                ps.setString(2, lName);
                ps.setString(3, uName);
                ps.setString(4, pWord);
                ps.setString(5, rPasswd);
                ps.execute();
                
                System.out.print("Data Saved");
                //lblPasswordConfirmation.setText("");
                //txtFirstName.setText("");
                //txtLastName.setText("");
                //txtUserName.setText("");
                //passwdPassword.setText("");
                //passwdRPassword.setText("");
                try {
                    loginRoot = (Parent) login.load();
                    loginStage.setScene(new Scene(loginRoot));
                    loginStage.getIcons().add(new Image("/resources/logokent.png"));
                    loginStage.setTitle("Hydra Data Protection Tool");
                    loginStage.show();
                    HydraDataProtectionTool.stage1.close();
                    
                } catch (IOException ex) {
                    Logger.getLogger(RegisterController.class.getName()).log(Level.SEVERE, null, ex);
                }
        
            } catch (SQLException ex) {
                Logger.getLogger(RegisterController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else {
            lblPasswordConfirmation.setText("Password doesn't match");
            passwdPassword.setText("");
            passwdRPassword.setText("");
        }
    }
    @FXML
    public void toLogin(ActionEvent event) {
        try {
            loginRoot = (Parent) login.load();
            loginStage.setScene(new Scene(loginRoot));
            loginStage.getIcons().add(new Image("/resources/logokent.png"));
            loginStage.setTitle("Hydra Data Protection Tool");
            loginStage.show();
            HydraDataProtectionTool.stage1.close();
        } catch (IOException ex) {
            Logger.getLogger(RegisterController.class.getName()).log(Level.SEVERE, null, ex);
        }
                   

    }

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
