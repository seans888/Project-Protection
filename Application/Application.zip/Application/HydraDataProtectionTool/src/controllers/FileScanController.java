/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXProgressBar;
import com.jfoenix.controls.JFXTextArea;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ProgressIndicator;

/**
 * FXML Controller class
 *
 * @author Letty
 */
public class FileScanController implements Initializable {

    @FXML
    private JFXProgressBar DRBar;

    @FXML
    private JFXButton DataRepair;

    @FXML
    private ProgressIndicator CSIndicator;

    @FXML
    private JFXProgressBar CSBar;

    @FXML
    private ProgressIndicator DRIndicator;

    @FXML
    private JFXTextArea CSOutput;

    @FXML
    private JFXTextArea DROutput;

    @FXML
    private JFXButton CorruptionScan;
    Task copyWorker;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }  
    
    public Task createWorker() {
        return new Task() {
            @Override
            protected Object call() throws Exception {
                for (int i = 0; i < 20; i++) {
                    Thread.sleep(1000);
                    updateMessage("1000 milliseconds");
                    updateProgress(i + 1, 20);
                   
                  if(i== 19){
                       Process  process = Runtime.getRuntime().exec("cmd.exe /C start F:/Functioning/FileAcquireTitle.exe\"");
            System.out.println(process);
                  }

                        
                }
                return true;
            }
        };
    }
    
      @FXML
    public void csBtn(ActionEvent event) throws IOException {
                
       
        try {
            FileInputStream is = new FileInputStream("F:\\Hash\\HashValue.txt");
            BufferedReader bfReader = new BufferedReader(new InputStreamReader(is));
            String temp = null;
             while((temp = bfReader.readLine()) != null){
                CSOutput.appendText(temp);
            }
        } catch (FileNotFoundException e) {
        } catch (IOException e) {
        }
        
         copyWorker = createWorker();
         CSBar.setProgress(0);
         CSBar.progressProperty().unbind();
         CSBar.progressProperty().bind(copyWorker.progressProperty());
         CSIndicator.setProgress(0);
         CSIndicator.progressProperty().unbind();
         CSIndicator.progressProperty().bind(copyWorker.progressProperty());
         copyWorker.messageProperty().addListener((ObservableValue<? extends String> observable, String oldValue, String newValue) -> {
             System.out.println(newValue);
        });
     new Thread(copyWorker).start();

    }

    @FXML
    public void drBtn(ActionEvent event) {
        try {
            createWorker();
             InputStream is = new FileInputStream("F:\\Hash\\NotSameValue.txt");
            BufferedReader bfReader = new BufferedReader(new InputStreamReader(is));
            String temp = null;
            while((temp = bfReader.readLine()) != null){
                DROutput.appendText(temp);
            }
        } catch (FileNotFoundException e) {
        } catch (IOException e) {
        }
            copyWorker = createWorker();
            DRIndicator.setProgress(0);
            DRIndicator.progressProperty().unbind();
            DRIndicator.progressProperty().bind(copyWorker.progressProperty());
            DRBar.setProgress(0);
            DRBar.progressProperty().unbind();
            DRBar.progressProperty().bind(copyWorker.progressProperty());
            copyWorker.messageProperty().addListener((ObservableValue<? extends String> observable, String oldValue, String newValue) -> {
                System.out.println(newValue);
        });

                new Thread(copyWorker).start();

    }

    @FXML
    public void  csCancel(ActionEvent event) {
        CSBar.progressProperty().unbind();
        CSBar.setProgress(0);
        CSIndicator.progressProperty().unbind();
        CSIndicator.setProgress(0);
        System.out.println("cancelled.");


    }

    @FXML
    public void drCancel (ActionEvent event) {
        DRBar.progressProperty().unbind();
            DRBar.setProgress(0);
            DRIndicator.progressProperty().unbind();
            DRIndicator.setProgress(0);
            System.out.println("cancelled.");

    }
    
}
