package demos.gui.uicomponents;

import io.datafx.controller.FXMLController;

@FXMLController(value = "/resources/fxml/ui/Checkbox.fxml" , title = "Material Design Example")
public class CheckboxController {

}
