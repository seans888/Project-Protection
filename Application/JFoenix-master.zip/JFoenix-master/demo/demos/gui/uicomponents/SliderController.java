package demos.gui.uicomponents;

import io.datafx.controller.FXMLController;

@FXMLController(value = "/resources/fxml/ui/Slider.fxml", title = "Material Design Example")
public class SliderController {

}
