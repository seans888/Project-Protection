package demos.gui.uicomponents;

import io.datafx.controller.FXMLController;

@FXMLController(value = "/resources/fxml/ui/Button.fxml" , title = "Material Design Example")
public class ButtonController {
	
//	@FXMLViewFlowContext
//	private ViewFlowContext context;
//
//	@PostConstruct
//	public void init() throws FlowException, VetoException {
//		if(((Pane) context.getRegisteredObject("ContentPane")).getChildren().size() > 0)
//			Platform.runLater(()-> ((Pane)((Pane) context.getRegisteredObject("ContentPane")).getChildren().get(0)).getChildren().remove(1));
//	}

}
