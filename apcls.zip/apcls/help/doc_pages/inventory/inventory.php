<?php
require 'path.php';
init_cobalt();
require 'subclasses/inventory_doc.php';
$obj_doc = new inventory_doc;
$obj_doc->auto_doc();