<?php
require 'path.php';
init_cobalt();
require 'subclasses/requistion_detail_doc.php';
$obj_doc = new requistion_detail_doc;
$obj_doc->auto_doc();