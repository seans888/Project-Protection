<?php
require 'components/get_listview_referrer.php';

require 'subclasses/delivery.php';
$dbh_delivery = new delivery;
$dbh_delivery->set_where("delivery_id='" . quote_smart($delivery_id) . "' AND purchase_order_header_id='" . quote_smart($purchase_order_header_id) . "'");
if($result = $dbh_delivery->make_query()->result)
{
    $data = $result->fetch_assoc();
    extract($data);

    $data = explode('-',$date);
    if(count($data) == 3)
    {
        $date_year = $data[0];
        $date_month = $data[1];
        $date_day = $data[2];
    }
    $data = explode('-',$due_date);
    if(count($data) == 3)
    {
        $due_date_year = $data[0];
        $due_date_month = $data[1];
        $due_date_day = $data[2];
    }
}

