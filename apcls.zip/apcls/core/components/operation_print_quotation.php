<?php

echo "&nbsp;&nbsp;<a href='print_qoutation.php?$pkey_string' target='_blank'>[Print&nbsp;Quotation]</a>";
?>