<?php

echo "&nbsp;&nbsp;<a href='print_requisition.php?$pkey_string' target='_blank'>[Print&nbsp;Requisition]</a>";
?>