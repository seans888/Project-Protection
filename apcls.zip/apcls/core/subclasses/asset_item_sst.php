<?php
require_once 'sst_class.php';
require_once 'asset_item_dd.php';
class asset_item_sst extends sst
{
    function __construct()
    {
        $this->fields        = asset_item_dd::load_dictionary();
        $this->relations     = asset_item_dd::load_relationships();
        $this->subclasses    = asset_item_dd::load_subclass_info();
        $this->table_name    = asset_item_dd::$table_name;
        $this->readable_name = asset_item_dd::$readable_name;
        parent::__construct();
    }
}
