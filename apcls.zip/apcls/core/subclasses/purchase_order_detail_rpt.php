<?php
require_once 'purchase_order_detail_dd.php';
class purchase_order_detail_rpt extends reporter
{
    var $tables='';
    var $session_array_name = 'PURCHASE_ORDER_DETAIL_REPORT_CUSTOM';
    var $report_title = '%%: Custom Reporting Tool';
    var $html_subclass = 'purchase_order_detail_html';
    var $data_subclass = 'purchase_order_detail';
    var $result_page = 'reporter_result_purchase_order_detail.php';
    var $cancel_page = 'listview_purchase_order_detail.php';
    var $pdf_reporter_filename = 'reporter_pdfresult_purchase_order_detail.php';

    function __construct()
    {
        $this->fields        = purchase_order_detail_dd::load_dictionary();
        $this->relations     = purchase_order_detail_dd::load_relationships();
        $this->subclasses    = purchase_order_detail_dd::load_subclass_info();
        $this->table_name    = purchase_order_detail_dd::$table_name;
        $this->tables        = purchase_order_detail_dd::$table_name;
        $this->readable_name = purchase_order_detail_dd::$readable_name;
        $this->get_report_fields();
    }
}
