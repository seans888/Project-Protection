<?php
require_once 'delivery_dd.php';
class delivery_rpt extends reporter
{
    var $tables='';
    var $session_array_name = 'DELIVERY_REPORT_CUSTOM';
    var $report_title = '%%: Custom Reporting Tool';
    var $html_subclass = 'delivery_html';
    var $data_subclass = 'delivery';
    var $result_page = 'reporter_result_delivery.php';
    var $cancel_page = 'listview_delivery.php';
    var $pdf_reporter_filename = 'reporter_pdfresult_delivery.php';

    function __construct()
    {
        $this->fields        = delivery_dd::load_dictionary();
        $this->relations     = delivery_dd::load_relationships();
        $this->subclasses    = delivery_dd::load_subclass_info();
        $this->table_name    = delivery_dd::$table_name;
        $this->tables        = delivery_dd::$table_name;
        $this->readable_name = delivery_dd::$readable_name;
        $this->get_report_fields();
    }
}
