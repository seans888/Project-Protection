<?php
require_once 'purchase_order_header_dd.php';
class purchase_order_header_rpt extends reporter
{
    var $tables='';
    var $session_array_name = 'PURCHASE_ORDER_HEADER_REPORT_CUSTOM';
    var $report_title = '%%: Custom Reporting Tool';
    var $html_subclass = 'purchase_order_header_html';
    var $data_subclass = 'purchase_order_header';
    var $result_page = 'reporter_result_purchase_order_header.php';
    var $cancel_page = 'listview_purchase_order_header.php';
    var $pdf_reporter_filename = 'reporter_pdfresult_purchase_order_header.php';

    function __construct()
    {
        $this->fields        = purchase_order_header_dd::load_dictionary();
        $this->relations     = purchase_order_header_dd::load_relationships();
        $this->subclasses    = purchase_order_header_dd::load_subclass_info();
        $this->table_name    = purchase_order_header_dd::$table_name;
        $this->tables        = purchase_order_header_dd::$table_name;
        $this->readable_name = purchase_order_header_dd::$readable_name;
        $this->get_report_fields();
    }
}
