<?php
require_once 'supplier_dd.php';
class supplier_rpt extends reporter
{
    var $tables='';
    var $session_array_name = 'SUPPLIER_REPORT_CUSTOM';
    var $report_title = '%%: Custom Reporting Tool';
    var $html_subclass = 'supplier_html';
    var $data_subclass = 'supplier';
    var $result_page = 'reporter_result_supplier.php';
    var $cancel_page = 'listview_supplier.php';
    var $pdf_reporter_filename = 'reporter_pdfresult_supplier.php';

    function __construct()
    {
        $this->fields        = supplier_dd::load_dictionary();
        $this->relations     = supplier_dd::load_relationships();
        $this->subclasses    = supplier_dd::load_subclass_info();
        $this->table_name    = supplier_dd::$table_name;
        $this->tables        = supplier_dd::$table_name;
        $this->readable_name = supplier_dd::$readable_name;
        $this->get_report_fields();
    }
}
