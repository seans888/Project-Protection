<?php
require_once 'requistion_detail_dd.php';
class requistion_detail_rpt extends reporter
{
    var $tables='';
    var $session_array_name = 'REQUISTION_DETAIL_REPORT_CUSTOM';
    var $report_title = '%%: Custom Reporting Tool';
    var $html_subclass = 'requistion_detail_html';
    var $data_subclass = 'requistion_detail';
    var $result_page = 'reporter_result_requistion_detail.php';
    var $cancel_page = 'listview_requistion_detail.php';
    var $pdf_reporter_filename = 'reporter_pdfresult_requistion_detail.php';

    function __construct()
    {
        $this->fields        = requistion_detail_dd::load_dictionary();
        $this->relations     = requistion_detail_dd::load_relationships();
        $this->subclasses    = requistion_detail_dd::load_subclass_info();
        $this->table_name    = requistion_detail_dd::$table_name;
        $this->tables        = requistion_detail_dd::$table_name;
        $this->readable_name = requistion_detail_dd::$readable_name;
        $this->get_report_fields();
    }
}
