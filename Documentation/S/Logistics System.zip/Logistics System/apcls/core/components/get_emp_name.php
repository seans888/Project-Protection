<?php 

// require 'path.php';
// init_cobalt();

    function get_emp_name($b)
    {
        $d = cobalt_load_class('employee');
        $d->set_fields('first_name,middle_name,last_name');
        $d->set_where('employee_id ='.$b.'');
        // debug($emp_id);

        $d->exec_fetch('single');
        $name = $d->dump['first_name'].' '.$d->dump['middle_name'].' '.$d->dump['last_name'];
        return $name;
    }
?>