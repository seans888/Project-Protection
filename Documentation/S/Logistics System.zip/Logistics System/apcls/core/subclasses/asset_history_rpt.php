<?php
require_once 'asset_history_dd.php';
class asset_history_rpt extends reporter
{
    var $tables='';
    var $session_array_name = 'ASSET_HISTORY_REPORT_CUSTOM';
    var $report_title = '%%: Custom Reporting Tool';
    var $html_subclass = 'asset_history_html';
    var $data_subclass = 'asset_history';
    var $result_page = 'reporter_result_asset_history.php';
    var $cancel_page = 'listview_asset_history.php';
    var $pdf_reporter_filename = 'reporter_pdfresult_asset_history.php';

    function __construct()
    {
        $this->fields        = asset_history_dd::load_dictionary();
        $this->relations     = asset_history_dd::load_relationships();
        $this->subclasses    = asset_history_dd::load_subclass_info();
        $this->table_name    = asset_history_dd::$table_name;
        $this->tables        = asset_history_dd::$table_name;
        $this->readable_name = asset_history_dd::$readable_name;
        $this->get_report_fields();
    }
}
