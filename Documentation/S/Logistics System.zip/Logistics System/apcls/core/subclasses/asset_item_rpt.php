<?php
require_once 'asset_item_dd.php';
class asset_item_rpt extends reporter
{
    var $tables='';
    var $session_array_name = 'ASSET_ITEM_REPORT_CUSTOM';
    var $report_title = '%%: Custom Reporting Tool';
    var $html_subclass = 'asset_item_html';
    var $data_subclass = 'asset_item';
    var $result_page = 'reporter_result_asset_item.php';
    var $cancel_page = 'listview_asset_item.php';
    var $pdf_reporter_filename = 'reporter_pdfresult_asset_item.php';

    function __construct()
    {
        $this->fields        = asset_item_dd::load_dictionary();
        $this->relations     = asset_item_dd::load_relationships();
        $this->subclasses    = asset_item_dd::load_subclass_info();
        $this->table_name    = asset_item_dd::$table_name;
        $this->tables        = asset_item_dd::$table_name;
        $this->readable_name = asset_item_dd::$readable_name;
        $this->get_report_fields();
    }
}
