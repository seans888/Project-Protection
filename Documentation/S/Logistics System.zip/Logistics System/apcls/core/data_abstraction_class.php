<?php
require 'base_data_abstraction_class.php';
class data_abstraction extends base_data_abstraction
{

}