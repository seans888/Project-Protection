<?php
require 'path.php';
init_cobalt();
require 'subclasses/supplier_doc.php';
$obj_doc = new supplier_doc;
$obj_doc->auto_doc();