<?php
require 'components/get_listview_referrer.php';

require 'subclasses/asset_item_inventory.php';
$dbh_asset_item_inventory = new asset_item_inventory;
$dbh_asset_item_inventory->set_where("asset_item_inventory_id='" . quote_smart($asset_item_inventory_id) . "' AND asset_item_id='" . quote_smart($asset_item_id) . "'");
if($result = $dbh_asset_item_inventory->make_query()->result)
{
    $data = $result->fetch_assoc();
    extract($data);

}

