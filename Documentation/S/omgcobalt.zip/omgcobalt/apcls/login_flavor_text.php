<?php
if(isset($enable_flavor_text) && $enable_flavor_text=TRUE)
{
?>
    <!-- START OF LOGIN FLAVOR TEXT HTML -->







    <!-- END OF LOGIN FLAVOR TEXT HTML -->
<?php
}