<?php

echo "&nbsp;&nbsp;<a href='print_purchase_order.php?$pkey_string' target='_blank'>[Print&nbsp;Purchase&nbsp;Order]</a>";
?>