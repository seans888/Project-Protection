<?php
require_once 'quotation_detail_dd.php';
class quotation_detail_rpt extends reporter
{
    var $tables='';
    var $session_array_name = 'QUOTATION_DETAIL_REPORT_CUSTOM';
    var $report_title = '%%: Custom Reporting Tool';
    var $html_subclass = 'quotation_detail_html';
    var $data_subclass = 'quotation_detail';
    var $result_page = 'reporter_result_quotation_detail.php';
    var $cancel_page = 'listview_quotation_detail.php';
    var $pdf_reporter_filename = 'reporter_pdfresult_quotation_detail.php';

    function __construct()
    {
        $this->fields        = quotation_detail_dd::load_dictionary();
        $this->relations     = quotation_detail_dd::load_relationships();
        $this->subclasses    = quotation_detail_dd::load_subclass_info();
        $this->table_name    = quotation_detail_dd::$table_name;
        $this->tables        = quotation_detail_dd::$table_name;
        $this->readable_name = quotation_detail_dd::$readable_name;
        $this->get_report_fields();
    }
}
