<?php
require_once 'purchase_order_detail_dd.php';
class purchase_order_detail extends data_abstraction
{
    var $fields = array();


    function __construct()
    {
        $this->fields     = purchase_order_detail_dd::load_dictionary();
        $this->relations  = purchase_order_detail_dd::load_relationships();
        $this->subclasses = purchase_order_detail_dd::load_subclass_info();
        $this->table_name = purchase_order_detail_dd::$table_name;
        $this->tables     = purchase_order_detail_dd::$table_name;
    }

    function add($param)
    {
        $this->set_parameters($param);

        if($this->stmt_template=='')
        {
            $this->set_query_type('INSERT');
            $this->set_fields('purchase_order_detail_id, purchase_order_header_id, particulars, unit_of_measurement, quantity, unit_cost, amount');
            $this->set_values("?,?,?,?,?,?,?");

            $bind_params = array('iisssss',
                                 &$this->fields['purchase_order_detail_id']['value'],
                                 &$this->fields['purchase_order_header_id']['value'],
                                 &$this->fields['particulars']['value'],
                                 &$this->fields['unit_of_measurement']['value'],
                                 &$this->fields['quantity']['value'],
                                 &$this->fields['unit_cost']['value'],
                                 &$this->fields['amount']['value']);

            $this->stmt_prepare($bind_params);
        }

        $this->stmt_execute();
        return $this;
    }

    function edit($param)
    {
        $this->set_parameters($param);

        if($this->stmt_template=='')
        {
            $this->set_query_type('UPDATE');
            $this->set_update("purchase_order_header_id = ?, particulars = ?, unit_of_measurement = ?, quantity = ?, unit_cost = ?, amount = ?");
            $this->set_where("purchase_order_detail_id = ?");

            $bind_params = array('isssssi',
                                 &$this->fields['purchase_order_header_id']['value'],
                                 &$this->fields['particulars']['value'],
                                 &$this->fields['unit_of_measurement']['value'],
                                 &$this->fields['quantity']['value'],
                                 &$this->fields['unit_cost']['value'],
                                 &$this->fields['amount']['value'],
                                 &$this->fields['purchase_order_detail_id']['value']);

            $this->stmt_prepare($bind_params);
        }
        $this->stmt_execute();

        return $this;
    }

    function delete($param)
    {
        $this->set_parameters($param);
        $this->set_query_type('DELETE');
        $this->set_where("purchase_order_detail_id = ?");

        $bind_params = array('i',
                             &$this->fields['purchase_order_detail_id']['value']);

        $this->stmt_prepare($bind_params);
        $this->stmt_execute();
        $this->stmt_close();

        return $this;
    }

    function delete_many($param)
    {
        $this->set_parameters($param);
        $this->set_query_type('DELETE');
        $this->set_where("purchase_order_header_id = ?");

        $bind_params = array('i',
                             &$this->fields['purchase_order_header_id']['value']);

        $this->stmt_prepare($bind_params);
        $this->stmt_execute();
        $this->stmt_close();

        return $this;
    }

    function select()
    {
        $this->set_query_type('SELECT');
        $this->exec_fetch('array');
        return $this;
    }

    function check_uniqueness($param)
    {
        $this->set_parameters($param);
        $this->set_query_type('SELECT');
        $this->set_where("purchase_order_detail_id = ?");

        $bind_params = array('i',
                             &$this->fields['purchase_order_detail_id']['value']);

        $this->stmt_prepare($bind_params);
        $this->stmt_execute();
        $this->stmt_close();

        if($this->num_rows > 0) $this->is_unique = FALSE;
        else $this->is_unique = TRUE;

        return $this;
    }

    function check_uniqueness_for_editing($param)
    {
        $this->set_parameters($param);


        $this->set_query_type('SELECT');
        $this->set_where("purchase_order_detail_id = ? AND (purchase_order_detail_id != ?)");

        $bind_params = array('ii',
                             &$this->fields['purchase_order_detail_id']['value'],
                             &$this->fields['purchase_order_detail_id']['value']);

        $this->stmt_prepare($bind_params);
        $this->stmt_execute();
        $this->stmt_close();

        if($this->num_rows > 0) $this->is_unique = FALSE;
        else $this->is_unique = TRUE;

        return $this;
    }
}
