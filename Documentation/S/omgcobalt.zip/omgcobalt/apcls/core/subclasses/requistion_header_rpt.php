<?php
require_once 'requistion_header_dd.php';
class requistion_header_rpt extends reporter
{
    var $tables='';
    var $session_array_name = 'REQUISTION_HEADER_REPORT_CUSTOM';
    var $report_title = '%%: Custom Reporting Tool';
    var $html_subclass = 'requistion_header_html';
    var $data_subclass = 'requistion_header';
    var $result_page = 'reporter_result_requistion_header.php';
    var $cancel_page = 'listview_requistion_header.php';
    var $pdf_reporter_filename = 'reporter_pdfresult_requistion_header.php';

    function __construct()
    {
        $this->fields        = requistion_header_dd::load_dictionary();
        $this->relations     = requistion_header_dd::load_relationships();
        $this->subclasses    = requistion_header_dd::load_subclass_info();
        $this->table_name    = requistion_header_dd::$table_name;
        $this->tables        = requistion_header_dd::$table_name;
        $this->readable_name = requistion_header_dd::$readable_name;
        $this->get_report_fields();
    }
}
