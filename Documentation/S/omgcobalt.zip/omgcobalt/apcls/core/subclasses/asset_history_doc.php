<?php
require_once 'documentation_class.php';
require_once 'asset_history_dd.php';
class asset_history_doc extends documentation
{
    function __construct()
    {
        $this->fields        = asset_history_dd::load_dictionary();
        $this->relations     = asset_history_dd::load_relationships();
        $this->subclasses    = asset_history_dd::load_subclass_info();
        $this->table_name    = asset_history_dd::$table_name;
        $this->readable_name = asset_history_dd::$readable_name;
        parent::__construct();
    }
}
