<?php
require 'base_graph_creator.php';
class graph_creator extends base_graph_creator
{

}