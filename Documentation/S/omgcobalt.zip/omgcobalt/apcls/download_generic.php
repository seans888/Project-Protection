<?php
require 'path.php';
init_cobalt('ALLOW_ALL');
$valid_directory = TMP_DIRECTORY;
require 'components/download.php';
