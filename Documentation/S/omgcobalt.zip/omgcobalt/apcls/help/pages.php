<?php
//List of modules (tables) for the table of contents to show
//The format is doc_subclass_name => doc_dir_name
$content_pages = array(
        'asset_history_doc'=>'asset_history',
        'asset_item_doc'=>'asset_item',
        'asset_item_inventory_doc'=>'asset_item_inventory',
        'award_doc'=>'award',
        'delivery_doc'=>'delivery',
        'department_doc'=>'department',
        'employee_doc'=>'employee',
        'item_doc'=>'item',
        'purchase_order_detail_doc'=>'purchase_order_detail',
        'purchase_order_header_doc'=>'purchase_order_header',
        'quotation_detail_doc'=>'quotation_detail',
        'quotation_header_doc'=>'quotation_header',
        'requistion_detail_doc'=>'requistion_detail',
        'requistion_header_doc'=>'requistion_header',
        'supplier_doc'=>'supplier',
        'transaction_details_doc'=>'transaction_details',
        'transaction_header_doc'=>'transaction_header',
);