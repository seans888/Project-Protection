<?php
require 'path.php';
init_cobalt();
require 'subclasses/requistion_header_doc.php';
$obj_doc = new requistion_header_doc;
$obj_doc->auto_doc();