<?php
require 'path.php';
init_cobalt();
require 'subclasses/quotation_header_doc.php';
$obj_doc = new quotation_header_doc;
$obj_doc->auto_doc();