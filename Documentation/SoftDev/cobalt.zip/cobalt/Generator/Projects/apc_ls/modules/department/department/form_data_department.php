<?php
require 'components/get_listview_referrer.php';

require 'subclasses/department.php';
$dbh_department = new department;
$dbh_department->set_where("department_id='" . quote_smart($department_id) . "'");
if($result = $dbh_department->make_query()->result)
{
    $data = $result->fetch_assoc();
    extract($data);

}

require_once 'subclasses/employee.php';
$dbh_employee = new employee;
$dbh_employee->set_fields('employee_id, position, first_name, middle_name, last_name, email_address, address, postal_code, telephone_number, mobile_number, gender, civil_status, birthday, birth_place, religion, tin_number');
$dbh_employee->set_where("department_id='" . quote_smart($department_id) . "'");
if($result = $dbh_employee->make_query()->result)
{
    $num_employee = $dbh_employee->num_rows;
    for($a=0; $a<$num_employee; $a++)
    {
        $data = $result->fetch_row();
        $cf_employee_employee_id[$a] = $data[0];
        $cf_employee_position[$a] = $data[1];
        $cf_employee_first_name[$a] = $data[2];
        $cf_employee_middle_name[$a] = $data[3];
        $cf_employee_last_name[$a] = $data[4];
        $cf_employee_email_address[$a] = $data[5];
        $cf_employee_address[$a] = $data[6];
        $cf_employee_postal_code[$a] = $data[7];
        $cf_employee_telephone_number[$a] = $data[8];
        $cf_employee_mobile_number[$a] = $data[9];
        $cf_employee_gender[$a] = $data[10];
        $cf_employee_civil_status[$a] = $data[11];
        $data_temp_cf_date = explode('-',$data[12]);
        $cf_employee_birthday_year[$a] = $data_temp_cf_date[0];
        $cf_employee_birthday_month[$a] = $data_temp_cf_date[1];
        $cf_employee_birthday_day[$a] = $data_temp_cf_date[2];
        $cf_employee_birth_place[$a] = $data[13];
        $cf_employee_religion[$a] = $data[14];
        $cf_employee_tin_number[$a] = $data[15];
    }
}

