<?php
require 'components/get_listview_referrer.php';

require 'subclasses/asset_history.php';
$dbh_asset_history = new asset_history;
$dbh_asset_history->set_where("asset_history_id='" . quote_smart($asset_history_id) . "' AND employee_id='" . quote_smart($employee_id) . "' AND asset_item_id='" . quote_smart($asset_item_id) . "'");
if($result = $dbh_asset_history->make_query()->result)
{
    $data = $result->fetch_assoc();
    extract($data);

    $data = explode('-',$date);
    if(count($data) == 3)
    {
        $date_year = $data[0];
        $date_month = $data[1];
        $date_day = $data[2];
    }
}

