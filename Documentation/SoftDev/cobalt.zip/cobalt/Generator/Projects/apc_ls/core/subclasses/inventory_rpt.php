<?php
require_once 'inventory_dd.php';
class inventory_rpt extends reporter
{
    var $tables='';
    var $session_array_name = 'INVENTORY_REPORT_CUSTOM';
    var $report_title = '%%: Custom Reporting Tool';
    var $html_subclass = 'inventory_html';
    var $data_subclass = 'inventory';
    var $result_page = 'reporter_result_inventory.php';
    var $cancel_page = 'listview_inventory.php';
    var $pdf_reporter_filename = 'reporter_pdfresult_inventory.php';

    function __construct()
    {
        $this->fields        = inventory_dd::load_dictionary();
        $this->relations     = inventory_dd::load_relationships();
        $this->subclasses    = inventory_dd::load_subclass_info();
        $this->table_name    = inventory_dd::$table_name;
        $this->tables        = inventory_dd::$table_name;
        $this->readable_name = inventory_dd::$readable_name;
        $this->get_report_fields();
    }
}
