<?php
require_once 'sst_class.php';
require_once 'delivery_dd.php';
class delivery_sst extends sst
{
    function __construct()
    {
        $this->fields        = delivery_dd::load_dictionary();
        $this->relations     = delivery_dd::load_relationships();
        $this->subclasses    = delivery_dd::load_subclass_info();
        $this->table_name    = delivery_dd::$table_name;
        $this->readable_name = delivery_dd::$readable_name;
        parent::__construct();
    }
}
