<?php
require_once 'documentation_class.php';
require_once 'transaction_dd.php';
class transaction_doc extends documentation
{
    function __construct()
    {
        $this->fields        = transaction_dd::load_dictionary();
        $this->relations     = transaction_dd::load_relationships();
        $this->subclasses    = transaction_dd::load_subclass_info();
        $this->table_name    = transaction_dd::$table_name;
        $this->readable_name = transaction_dd::$readable_name;
        parent::__construct();
    }
}
