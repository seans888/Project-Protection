<?php
require_once 'sst_class.php';
require_once 'inventory_dd.php';
class inventory_sst extends sst
{
    function __construct()
    {
        $this->fields        = inventory_dd::load_dictionary();
        $this->relations     = inventory_dd::load_relationships();
        $this->subclasses    = inventory_dd::load_subclass_info();
        $this->table_name    = inventory_dd::$table_name;
        $this->readable_name = inventory_dd::$readable_name;
        parent::__construct();
    }
}
