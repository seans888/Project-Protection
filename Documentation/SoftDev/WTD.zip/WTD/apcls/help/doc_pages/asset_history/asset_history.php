<?php
require 'path.php';
init_cobalt();
require 'subclasses/asset_history_doc.php';
$obj_doc = new asset_history_doc;
$obj_doc->auto_doc();