<?php
require 'path.php';
init_cobalt();
require 'subclasses/transaction_details_doc.php';
$obj_doc = new transaction_details_doc;
$obj_doc->auto_doc();