<?php
require 'path.php';
init_cobalt();
require 'subclasses/asset_item_doc.php';
$obj_doc = new asset_item_doc;
$obj_doc->auto_doc();