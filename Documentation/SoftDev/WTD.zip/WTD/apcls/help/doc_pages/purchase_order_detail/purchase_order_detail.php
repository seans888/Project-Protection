<?php
require 'path.php';
init_cobalt();
require 'subclasses/purchase_order_detail_doc.php';
$obj_doc = new purchase_order_detail_doc;
$obj_doc->auto_doc();