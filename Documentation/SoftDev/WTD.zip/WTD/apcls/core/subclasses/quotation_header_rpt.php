<?php
require_once 'quotation_header_dd.php';
class quotation_header_rpt extends reporter
{
    var $tables='';
    var $session_array_name = 'QUOTATION_HEADER_REPORT_CUSTOM';
    var $report_title = '%%: Custom Reporting Tool';
    var $html_subclass = 'quotation_header_html';
    var $data_subclass = 'quotation_header';
    var $result_page = 'reporter_result_quotation_header.php';
    var $cancel_page = 'listview_quotation_header.php';
    var $pdf_reporter_filename = 'reporter_pdfresult_quotation_header.php';

    function __construct()
    {
        $this->fields        = quotation_header_dd::load_dictionary();
        $this->relations     = quotation_header_dd::load_relationships();
        $this->subclasses    = quotation_header_dd::load_subclass_info();
        $this->table_name    = quotation_header_dd::$table_name;
        $this->tables        = quotation_header_dd::$table_name;
        $this->readable_name = quotation_header_dd::$readable_name;
        $this->get_report_fields();
    }
}
