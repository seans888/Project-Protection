<?php
require_once 'documentation_class.php';
require_once 'quotation_detail_dd.php';
class quotation_detail_doc extends documentation
{
    function __construct()
    {
        $this->fields        = quotation_detail_dd::load_dictionary();
        $this->relations     = quotation_detail_dd::load_relationships();
        $this->subclasses    = quotation_detail_dd::load_subclass_info();
        $this->table_name    = quotation_detail_dd::$table_name;
        $this->readable_name = quotation_detail_dd::$readable_name;
        parent::__construct();
    }
}
