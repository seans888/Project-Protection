<?php
require 'components/get_listview_referrer.php';

require 'subclasses/asset_item.php';
$dbh_asset_item = new asset_item;
$dbh_asset_item->set_where("asset_item_id='" . quote_smart($asset_item_id) . "'");
if($result = $dbh_asset_item->make_query()->result)
{
    $data = $result->fetch_assoc();
    extract($data);

}

require_once 'subclasses/asset_history.php';
$dbh_asset_history = new asset_history;
$dbh_asset_history->set_fields('employee_id, date, designation');
$dbh_asset_history->set_where("asset_item_id='" . quote_smart($asset_item_id) . "'");
if($result = $dbh_asset_history->make_query()->result)
{
    $num_asset_history = $dbh_asset_history->num_rows;
    for($a=0; $a<$num_asset_history; $a++)
    {
        $data = $result->fetch_row();
        $cf_asset_history_employee_id[$a] = $data[0];
        $data_temp_cf_date = explode('-',$data[1]);
        $cf_asset_history_date_year[$a] = $data_temp_cf_date[0];
        $cf_asset_history_date_month[$a] = $data_temp_cf_date[1];
        $cf_asset_history_date_day[$a] = $data_temp_cf_date[2];
        $cf_asset_history_designation[$a] = $data[2];
    }
}

